const https = require('https');
const token = 'eyJraWQiOiIyMDIyMDMxNzA4MjMiLCJhbGciOiJSUzI1NiJ9.eyJpYW1faWQiOiJJQk1pZC02NjMwMDI5M1NIIiwiaWQiOiJJQk1pZC02NjMwMDI5M1NIIiwicmVhbG1pZCI6IklCTWlkIiwianRpIjoiYWZhZGJjOTEtZDFmNS00MmViLWJiYTItODI0OTM5ZGMyMjE1IiwiaWRlbnRpZmllciI6IjY2MzAwMjkzU0giLCJnaXZlbl9uYW1lIjoiTnVwdXIiLCJmYW1pbHlfbmFtZSI6Ik5lZ2kiLCJuYW1lIjoiTnVwdXIgTmVnaSIsImVtYWlsIjoiTnVwdXIuTmVnaTJAaWJtLmNvbSIsInN1YiI6Ik51cHVyLk5lZ2kyQGlibS5jb20iLCJhdXRobiI6eyJzdWIiOiJOdXB1ci5OZWdpMkBpYm0uY29tIiwiaWFtX2lkIjoiSUJNaWQtNjYzMDAyOTNTSCIsIm5hbWUiOiJOdXB1ciBOZWdpIiwiZ2l2ZW5fbmFtZSI6Ik51cHVyIiwiZmFtaWx5X25hbWUiOiJOZWdpIiwiZW1haWwiOiJOdXB1ci5OZWdpMkBpYm0uY29tIn0sImFjY291bnQiOnsiYm91bmRhcnkiOiJnbG9iYWwiLCJ2YWxpZCI6dHJ1ZSwiYnNzIjoiNzFjYmRhNGM3N2FmNDgwY2E4YzViYmQ0N2JjYWIyMTYiLCJmcm96ZW4iOnRydWV9LCJpYXQiOjE2NDg0NTk3MjYsImV4cCI6MTY0ODQ2MzMyNiwiaXNzIjoiaHR0cHM6Ly9pYW0uY2xvdWQuaWJtLmNvbS9vaWRjL3Rva2VuIiwiZ3JhbnRfdHlwZSI6InVybjppYm06cGFyYW1zOm9hdXRoOmdyYW50LXR5cGU6YXBpa2V5Iiwic2NvcGUiOiJpYm0gb3BlbmlkIiwiY2xpZW50X2lkIjoiZGVmYXVsdCIsImFjciI6MSwiYW1yIjpbInB3ZCJdfQ.WiiKLFl7B8-bFzfyZyD11i5ElsC-YEEZcgorI3J5gEhFeiACCvCMPaLoeKCbE5dBlPpZXvNtZZXS4lu9M1kdpAkVYF-TRfxufdzNlr0jT_tRb4gFJs46wdQkN3UvcLAo01ZupZCpzXK7EmUahkwRXPoenH-n9ZEyeq97HrcUd5G-1J_O7MVznAFuxSJNjAWKJryLwsjO1FMHS3xP6MOGTgQXz3XFfBnsPO4NttC7cXd4SBKF7CPRW9DWxPU1_bps3VNpe-TBJOCj4-fHzqZEmMWCS550QQIiatfbxYq49cEjcxs74qA4q1cHrB4s08vDyrkdiDaeT1S-iVTgGxXcDQ';
const iamToken = Bearer + token;
const scoring_url = https://us-south.ml.cloud.ibm.com/ml/v4/deployments/31c39367-900b-4960-9d15-0c5b91164ae6/predictions?version=2022-03-21
const scoring_hostname = scoring_url.split('://')[1].split('.com')[0] + ".com";
const path = scoring_url.split('.com')[1];
let port=0;

scoring_url.split('://')[0] === "https" ? port=443 : port=80;

// API call setup

const APIcall = async (options, payload) => {

    const promise = new Promise(function(resolve, reject) {
        var req = https.request(options, function(res) {
          res.setEncoding('utf8');
    
          res.on('data', function (data) {
            let result = JSON.parse(data);
            resolve(result.predictions[0].values[0]);
          });
        });
        
        req.on('error', function(e) {
          reject('problem with request: ' + e.message);
        });
        
        req.write(JSON.stringify(payload));
        
        req.end();
    });
      return promise;
};

// Convert the Kinesis Stream into an array

const processData = (data) => {
    const regex = /[0-9]+(\.[0-9]+)?/g;
    let array_of_values_to_be_scored = [];
    let datarefined = data.data.split('\r\n');
    for(let i = 1; i < datarefined.length-1; i++){
        let temp = datarefined[i].match(regex);
        // parse int the string to int
        
        if (temp != null) {
            for(let j = 0; j < temp.length; j++){
                temp[j] = parseFloat(temp[j]);
            }
            array_of_values_to_be_scored.push(temp); 
        }
    }

    return (array_of_values_to_be_scored);
};

// AWS Lambda event handler

exports.handler = async function(event) {
    
    let scoringpayload = [];
    
    for (const records of event.Records){
        const data = JSON.parse(Buffer.from(records.kinesis.data, 'base64'));
        
        console.log('\n\n' +'--------------------------\n'
            +'Amazon Kinesis stream data\n' +'--------------------------\n'
            + ' ',data);
        
        scoringpayload = processData(data); 
    }
        
    // Prepare the API to make a request
  
    const array_of_input_fields = ["age","sex","cp","trtbps","chol","fbs","restecg","thalachh","exng","oldpeak","slp","caa","thall","spO2"];
    
    const array_of_values_to_be_scored = scoringpayload;
    
    let options = {
        hostname: scoring_hostname,
        port: port,
        path: path,
        method: "POST",
        headers: {
            'Authorization': iamToken,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        rejectUnauthorized: false
    };
    
    // Handle the API response
    
    let result = {
      "labels": [...array_of_input_fields, "model_output","output_confidence"],
      "values": []
    };
    
    let tableView = [];
    let output = [];
    
    for (let i=0; i<array_of_values_to_be_scored.length; i++){
        let input = array_of_values_to_be_scored[i];
        let temp = {};
        const payload = {"input_data": [{"fields": array_of_input_fields, "values": [input]}]};
        let modelScores = await APIcall(options, payload);
      
        output = [...input, modelScores[0], modelScores[1]];
        
        for (let k=0; k<result.labels.length; k++){
            temp[result.labels[k]] =  output[k];
        }
        tableView.push(temp);
      
        result.values.push([...input, modelScores[0], modelScores[1]]);
    }
    
    // Print the results
    
    console.log('\n\n' +'---------------------------------------------------\n'
      +'IBM Cloud Pak for Data Machine Learning Predictions \n' +'---------------------------------------------------\n');
    
    console.table(tableView);
    
    return result;
};